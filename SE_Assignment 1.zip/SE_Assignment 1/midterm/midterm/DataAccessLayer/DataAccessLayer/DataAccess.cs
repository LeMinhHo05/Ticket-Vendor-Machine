﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient; // Make sure to add System.Data.SqlClient NuGet package if needed (.NET Core+)

public class Station
{
    public int StationID { get; set; }
    public string StationName { get; set; }

    // Override ToString for easy display in ListBox/ComboBox
    public override string ToString()
    {
        return StationName;
    }
}

public static class DataAccess // Static class for simplicity in demo
{
    
    // !!! IMPORTANT: Store connection strings securely (e.g., app.config), not hardcoded!
    private static string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database =Re8;Integrated Security=True;";
    // Or use SQL Server Authentication: "Server=YOUR_SERVER_NAME;Database=YourDatabaseName;User ID=your_user;Password=your_password;";


    public static List<Station> GetStations()
    {
        SqlConnection connection = new SqlConnection(connectionString);
        List<Station> stations = new List<Station>();
        string query = "SELECT StationID, StationName FROM Stations ORDER BY StationName;";

        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            stations.Add(new Station
                            {
                                StationID = Convert.ToInt32(reader["StationID"]),
                                StationName = reader["StationName"].ToString()
                            });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Basic error logging or display
            Console.WriteLine($"Error getting stations: {ex.Message}");
            // In a real app, handle this more gracefully (e.g., show message to user)
        }
        return stations;
    }

    public static decimal? GetFare(int destinationStationId)
    {
        decimal? fare = null;
        // Simplified: Assumes only one fare entry per destination from the current location
        string query = "SELECT Price FROM Fares WHERE DestinationStationID = @DestinationID;";

        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DestinationID", destinationStationId);
                    conn.Open();
                    object result = cmd.ExecuteScalar(); // Use ExecuteScalar since we expect one value
                    if (result != null && result != DBNull.Value)
                    {
                        fare = Convert.ToDecimal(result);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error getting fare: {ex.Message}");
        }
        return fare;
    }

    public static bool LogTransaction(int? destinationStationId, decimal? fare, string paymentMethod, string status, string responseMessage)
    {
        string query = @"INSERT INTO Transactions
                         (Timestamp, DestinationStationID, Fare, PaymentMethod, Status, ResponseMessage)
                         VALUES
                         (GETDATE(), @DestinationID, @Fare, @PaymentMethod, @Status, @ResponseMessage);";
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Use parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@DestinationID", (object)destinationStationId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@Fare", (object)fare ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@PaymentMethod", (object)paymentMethod ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@ResponseMessage", (object)responseMessage ?? DBNull.Value);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0; // Return true if insert was successful
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error logging transaction: {ex.Message}");
            return false;
        }
    }
}
