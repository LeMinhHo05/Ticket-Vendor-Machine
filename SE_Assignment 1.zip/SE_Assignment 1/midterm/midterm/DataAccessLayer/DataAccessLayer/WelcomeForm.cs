﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public partial class WelcomeForm: Form
    {
        public WelcomeForm()
        {
            InitializeComponent();
        }
        private void startButton_Click(object sender, EventArgs e)
        {
            SelectDestinationForm destinationForm = new SelectDestinationForm();
            // Subscribe to the FormClosed event of the destination form
            // This allows WelcomeForm to know when destinationForm closes.
            destinationForm.FormClosed += DestinationForm_FormClosed;
            destinationForm.Show();
            this.Hide(); // Hide WelcomeForm
        }

        // Event Handler: Called when a form that we subscribed to closes
        private void DestinationForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // --- Navigation Logic: Re-show WelcomeForm if needed ---
            var confirmForm = Application.OpenForms.OfType<ConfirmPayForm>().FirstOrDefault();

            // Also check if this WelcomeForm is currently hidden and still valid.
            if (confirmForm == null && this.IsHandleCreated && !this.IsDisposed && !this.Visible)
            {

                this.Show();
            }

            // --- Unsubscribe ---

            if (sender is Form closedForm) // Safely cast sender to Form
            {
                closedForm.FormClosed -= DestinationForm_FormClosed;
            }
        }

        private void WelcomeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
