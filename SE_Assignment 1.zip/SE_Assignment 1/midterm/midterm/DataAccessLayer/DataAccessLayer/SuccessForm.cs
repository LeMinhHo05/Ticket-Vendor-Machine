﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public partial class SuccessForm: Form
    {
        public SuccessForm(string details)
        {
            InitializeComponent();
            if (details.Contains("WARNING:"))
            {
                detailsLabel.ForeColor = System.Drawing.Color.DarkOrange;
            }
            detailsLabel.Text = "TRANSACTION SUCCESSFUL!\n\n" + details;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            // Go back to WelcomeForm using safer OfType lookup
            var welcomeForm = Application.OpenForms.OfType<WelcomeForm>().FirstOrDefault();
            if (welcomeForm != null && !welcomeForm.IsDisposed)
            {
                welcomeForm.Show();
            }
            this.Close();
        }

        private void SuccessForm_Load(object sender, EventArgs e)
        {

        }
    }
}
