﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public partial class SelectDestinationForm: Form
    {
        public SelectDestinationForm()
        {
            InitializeComponent();
            LoadStations();
        }

        private void LoadStations()
        {
            List<Station> stations = null;
            try
            {
                // --- Data Access with Error Handling ---
                stations = DataAccess.GetStations(); // Attempt to load stations

                if (stations != null && stations.Count > 0)
                {
                    // --- Success Path: Populate ComboBox ---
                    destinationComboBox.DataSource = stations;
                    destinationComboBox.DisplayMember = "StationName";
                    destinationComboBox.ValueMember = "StationID";
                    destinationComboBox.SelectedIndex = -1; // No initial selection
                    destinationComboBox.Enabled = true;
                    selectButton.Enabled = true; // Enable selection
                }
                else
                {
                    // --- Failure Path (No Data): Handle gracefully ---

                    ShowLoadingError("No station data found. Please contact support.");
                }
            }
            catch (Exception ex)
            {
                // --- Failure Path (Exception): Handle unexpected errors ---

                Console.WriteLine($"UI Error loading stations: {ex.Message}"); // Log detailed error
                ShowLoadingError($"Could not load station data due to an error:\n{ex.Message}");
            }
        }

        // Helper method to show error and disable controls
        private void ShowLoadingError(string message)
        {
            MessageBox.Show(
                message,
                "Error Loading Data",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
            destinationComboBox.DataSource = null;
            destinationComboBox.Items.Clear();
            destinationComboBox.Items.Add("Loading failed");
            destinationComboBox.SelectedIndex = 0;
            destinationComboBox.Enabled = false;
            selectButton.Enabled = false; // Disable selection button
        }


        private void selectButton_Click(object sender, EventArgs e)
        {
            if (destinationComboBox.SelectedItem is Station selectedStation)
            {
                // --- Navigation ---
                ConfirmPayForm confirmForm = new ConfirmPayForm(selectedStation);

                confirmForm.Show();
                // Close this form *after* successfully navigating forward
                this.Close();
            }
            else
            {
                MessageBox.Show(
                    "Please select a destination.",
                    "Selection Required",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

            // Go back to WelcomeForm using safer OfType lookup
            var welcomeForm = Application.OpenForms.OfType<WelcomeForm>().FirstOrDefault();

            if (welcomeForm != null && !welcomeForm.IsDisposed)
            {
                welcomeForm.Show();
            }

            this.Close();
        }

        private void SelectDestinationForm_Load(object sender, EventArgs e)
        {

        }
    }
}
