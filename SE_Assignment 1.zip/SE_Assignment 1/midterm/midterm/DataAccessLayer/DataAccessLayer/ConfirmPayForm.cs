﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public partial class ConfirmPayForm: Form
    {
        private Station _selectedStation;
        private decimal? _currentFare;
        public ConfirmPayForm(Station selectedStation)
        {
            InitializeComponent();
            _selectedStation = selectedStation ?? throw new ArgumentNullException(nameof(selectedStation));
            DisplayFare();
        }

        private void DisplayFare()
        {
            destinationLabel.Text = $"Destination: {_selectedStation.StationName}";
            try
            {
                // --- Data Access with Error Handling ---
                _currentFare = DataAccess.GetFare(_selectedStation.StationID);

                if (_currentFare.HasValue)
                {
                    // --- Success Path ---
                    fareLabel.Text = $"Fare: {_currentFare.Value:C}";
                    payCreditCardButton.Enabled = true;
                    payQrButton.Enabled = true;
                }
                else
                {
                    // --- Failure Path (No Data/Error in GetFare) ---
                    ShowFareError("Could not retrieve fare for the selected destination.");
                }
            }
            catch (Exception ex) // Catch unexpected errors during fare retrieval
            {
                // --- Failure Path (Exception) ---
                Console.WriteLine($"UI Error getting fare: {ex.Message}");
                ShowFareError($"An error occurred retrieving fare:\n{ex.Message}");
            }
        }

        // Helper to show fare error and disable buttons
        private void ShowFareError(string message)
        {
            fareLabel.Text = "Fare: Not Available";
            MessageBox.Show(message, "Fare Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            payCreditCardButton.Enabled = false;
            payQrButton.Enabled = false;
        }


        private void payCreditCardButton_Click(object sender, EventArgs e)
        {
            ProcessPayment("CreditCard");
        }

        private void payQrButton_Click(object sender, EventArgs e)
        {
            ProcessPayment("QR"); // Changed to correct payment method string
        }

        // Centralized method to handle both payment types
        private void ProcessPayment(string paymentMethod)
        {
            // Pre-condition check
            if (!_currentFare.HasValue)
            {
                MessageBox.Show("Cannot proceed with payment as fare is unavailable.", "Payment Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            // --- Simulation Start ---
            string prompt = paymentMethod == "CreditCard"
                          ? "DEMO: Simulate Insert Credit Card?"
                          : "DEMO: Simulate Scan QR Code?";
            DialogResult startSim = MessageBox.Show(prompt, "Simulation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (startSim == DialogResult.No)
            {
                MessageBox.Show($"{paymentMethod} payment cancelled by user.", "Action Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return; // User cancelled the initial action simulation
            }

            // Simulate processing
            MessageBox.Show($"Processing {paymentMethod} Payment...\n(Simulating Gateway/Backend Interaction)", "Simulation", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Simulate gateway response
            DialogResult paymentSim = MessageBox.Show($"DEMO: Simulate {paymentMethod} Payment SUCCEEDS?", "Gateway Response Simulation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            // --- Handle Simulation Result ---
            bool logged = false; // Track logging success/failure
            string logStatus = "Unknown"; // Track outcome for logging
            string logMessage = ""; // Message for logging

            try // Add try-catch around the logging attempts
            {
                if (paymentSim == DialogResult.Yes) // --- Simulate SUCCESS ---
                {
                    logStatus = "Success";
                    string responseMessage = paymentMethod == "CreditCard" ? "Approved" : "QR Payment Approved"; // Base message
                    string ticketDetails = $"Ticket ID: TVM{new Random().Next(10000, 99999)}\n"
                                         + $"Destination: {_selectedStation.StationName}\n"
                                         + $"Fare: {_currentFare.Value:C}\n"
                                         + $"Paid via: {paymentMethod}";
                    logMessage = ticketDetails; // Log ticket details on success

                    // Attempt to log
                    logged = DataAccess.LogTransaction(_selectedStation.StationID, _currentFare, paymentMethod, logStatus, logMessage);

                    // Show Success Form (potentially with warning if logging failed)
                    string successDisplayMessage = ticketDetails;
                    if (!logged)
                    {
                        successDisplayMessage += "\n\nWARNING: Failed to save transaction log!";
                        MessageBox.Show("CRITICAL: Payment succeeded but failed to log transaction!", "Logging Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    SuccessForm successForm = new SuccessForm(successDisplayMessage);
                    successForm.Show();
                    this.Close(); // Close current form on success

                }
                else if (paymentSim == DialogResult.No) // --- Simulate FAILURE ---
                {
                    logStatus = "Failed";
                    string errorMessage = paymentMethod == "CreditCard"
                                        ? "Declined - Insufficient Funds (Simulated)"
                                        : "Declined - QR Code Invalid/Expired (Simulated)";
                    logMessage = errorMessage; // Log the error message

                    // Attempt to log
                    logged = DataAccess.LogTransaction(_selectedStation.StationID, _currentFare, paymentMethod, logStatus, logMessage);

                    // Show Failure Form (potentially with warning if logging failed)
                    if (!logged)
                    {
                        errorMessage += "\n\nWARNING: Failed to save transaction log!";
                        MessageBox.Show("CRITICAL: Payment failed AND failed to log transaction attempt!", "Logging Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    FailureForm failureForm = new FailureForm(errorMessage);
                    failureForm.Show();
                    this.Close(); // Close current form on failure

                }
                else // --- User chose Cancel on simulation ---
                {
                    logStatus = "Cancelled";
                    logMessage = "User cancelled during payment gateway simulation";
                    MessageBox.Show("Payment process cancelled during gateway interaction (simulated).", "Payment Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Attempt to log cancellation
                    logged = DataAccess.LogTransaction(_selectedStation.StationID, _currentFare, paymentMethod, logStatus, logMessage);
                    if (!logged)
                    {
                        MessageBox.Show("Warning: Failed to log cancellation record!", "Logging Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    // Decide where to go on cancel - back to Welcome? Or stay here? Let's go back to Welcome.
                    var welcomeForm = Application.OpenForms.OfType<WelcomeForm>().FirstOrDefault();
                    if (welcomeForm != null && !welcomeForm.IsDisposed) welcomeForm.Show();
                    this.Close();
                }
            }
            catch (Exception ex) // Catch unexpected errors during logging or form display
            {
                Console.WriteLine($"UI Error during payment processing/logging: {ex.Message}");
                MessageBox.Show($"A critical error occurred during payment finalization:\n{ex.Message}\nPlease contact support.", "Processing Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Maybe try to log this critical failure?
                try { DataAccess.LogTransaction(_selectedStation.StationID, _currentFare, paymentMethod, "Failed", $"Critical UI Error: {ex.Message}"); } catch { /* Ignore nested log error */ }
                // Go back to welcome screen after critical error
                var welcomeForm = Application.OpenForms.OfType<WelcomeForm>().FirstOrDefault();
                if (welcomeForm != null && !welcomeForm.IsDisposed) welcomeForm.Show();
                this.Close();
            }
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            // Go back to SelectDestinationForm using safer OfType lookup
            var destForm = Application.OpenForms.OfType<SelectDestinationForm>().FirstOrDefault();
            if (destForm != null && !destForm.IsDisposed)
            {
                destForm.Show();
            }
            else // Fallback to WelcomeForm if destination selection isn't open
            {
                var welcomeForm = Application.OpenForms.OfType<WelcomeForm>().FirstOrDefault();
                if (welcomeForm != null && !welcomeForm.IsDisposed) welcomeForm.Show();
            }
            this.Close();
        }

        private void ConfirmPayForm_Load(object sender, EventArgs e)
        {

        }
    }
}
