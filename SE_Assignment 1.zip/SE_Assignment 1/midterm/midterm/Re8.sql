-- Create a new database (if it doesn't exist)
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'YourDatabaseName')
BEGIN
    CREATE DATABASE Re8;
END
GO

-- Use the new database
USE Re8;
GO

-- Create Stations table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Stations')
BEGIN
    CREATE TABLE Stations (
        StationID INT PRIMARY KEY IDENTITY(1,1),
        StationName NVARCHAR(100) NOT NULL UNIQUE
    );
    PRINT 'Stations table created.';
END
GO

-- Create Fares table (Simplified for Demo)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Fares')
BEGIN
    CREATE TABLE Fares (
        FareID INT PRIMARY KEY IDENTITY(1,1),
        DestinationStationID INT NOT NULL,
        Price DECIMAL(10, 2) NOT NULL,
        CONSTRAINT FK_Fares_Stations FOREIGN KEY (DestinationStationID) REFERENCES Stations(StationID)
    );
    PRINT 'Fares table created.';
END
GO

-- Create Transactions table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Transactions')
BEGIN
    CREATE TABLE Transactions (
        TransactionID INT PRIMARY KEY IDENTITY(1,1),
        Timestamp DATETIME NOT NULL DEFAULT GETDATE(),
        DestinationStationID INT NULL, -- Allow NULL if transaction failed before selection
        Fare DECIMAL(10, 2) NULL,
        PaymentMethod VARCHAR(20) NULL, -- 'CreditCard', 'QR'
        Status VARCHAR(20) NOT NULL, -- 'Success', 'Failed', 'Cancelled'
        ResponseMessage NVARCHAR(500) NULL -- Error message or simulated ticket details
        -- Could add FK to Stations, but allow NULL if failure occurs early
    );
    PRINT 'Transactions table created.';
END
GO

-- Insert Sample Data (Optional, but helpful for testing)
IF (SELECT COUNT(*) FROM Stations) = 0
BEGIN
    INSERT INTO Stations (StationName) VALUES
    ('Ben Thanh Station'),
    ('Opera House Station'),
    ('Ba Son Station'),
    ('Van Thanh Park Station');

    INSERT INTO Fares (DestinationStationID, Price) VALUES
    ((SELECT StationID FROM Stations WHERE StationName = 'Ben Thanh Station'), 15000.00),
    ((SELECT StationID FROM Stations WHERE StationName = 'Opera House Station'), 12000.00),
    ((SELECT StationID FROM Stations WHERE StationName = 'Ba Son Station'), 18000.00),
    ((SELECT StationID FROM Stations WHERE StationName = 'Van Thanh Park Station'), 20000.00);

    PRINT 'Sample data inserted.';
END
GO

PRINT 'Database setup complete.';